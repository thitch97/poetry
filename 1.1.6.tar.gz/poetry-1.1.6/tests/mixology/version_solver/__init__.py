import pytest


pytest.register_assert_rewrite("tests.mixology.helpers")
